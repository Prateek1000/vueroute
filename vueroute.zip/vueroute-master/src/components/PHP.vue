<template>
  <div>
    <h2>PHP Course</h2>
  </div>
</template>

<script>
export default {
  name: "PHP",
};
</script>

<style></style>
