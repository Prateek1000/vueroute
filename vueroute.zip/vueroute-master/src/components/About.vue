<template>
  <div>
    <h2>This is about</h2>
    <p>The count is <Counter /></p>
  </div>
</template>

<script>
import Counter from "./Counter.vue";
export default {
  name: "About",
  components: { Counter },
};
</script>

<style></style>
