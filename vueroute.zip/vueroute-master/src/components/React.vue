<template>
  <div>
    <h2>React Course</h2>
  </div>
</template>

<script>
export default {
  name: "React",
};
</script>

<style></style>
