<template>
  <div>
    <h2>Click to select a course</h2>
  </div>
</template>

<script>
export default {
  name: "CoursesMessage",
};
</script>

<style></style>
