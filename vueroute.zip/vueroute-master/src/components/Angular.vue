<template>
  <div>
    <h2>Angular Course</h2>
  </div>
</template>

<script>
export default {
  name: "Angular",
};
</script>

<style></style>
